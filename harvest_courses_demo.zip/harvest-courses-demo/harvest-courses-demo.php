<?php

/**

Plugin Name: Harvest Courses - Demo 
Plugin URI: https://googlit.tech/word/wp/ 
Description: Courses management plugin for WordPress. Built by majdi awad for harvest training (Dubai) and this is just a demo version to be added to my resume.
Version: 1.0 
Author: Majdi Awad 
Author URI: http://googlit.tech/ 

Courses management plugin for WordPress. Built by majdi awad for harvest training (Dubai) and this is just a demo version to be added to my resume. 

Generate by Plugin Maker ~ http://codecanyon.net/item/wordpress-plugin-maker-freelancer-version/13581496

**/

# Exit if accessed directly
if (!defined("ABSPATH"))
{
	exit;
}

# Constant

/**
 * Exec Mode
 **/
define("HCM_EXEC",true);

/**
 * Plugin Base File
 **/
define("HCM_PATH",dirname(__FILE__));

/**
 * Plugin Base Directory
 **/
define("HCM_DIR",basename(HCM_PATH));

/**
 * Plugin Base URL
 **/
define("HCM_URL",plugins_url("/",__FILE__));

/**
 * Plugin Version
 **/
define("HCM_VERSION","1.0"); 

/**
 * Debug Mode
 **/
define("HCM_DEBUG",false);  //change false for distribution



/**
 * Base Class Plugin
 * @author Majdi Awad
 *
 * @access public
 * @version 1.0
 * @package Harvest Courses - Demo
 *
 **/

class HarvestCoursesDemo
{

	/**
	 * Instance of a class
	 * @access public
	 * @return void
	 **/

	function __construct()
	{
		add_action("plugins_loaded", array($this, "HCM_textdomain")); //load language/textdomain
		add_action("wp_enqueue_scripts",array($this,"HCM_enqueue_scripts")); //add js
		add_action("wp_enqueue_scripts",array($this,"HCM_enqueue_styles")); //add css
		add_action("init", array($this, "HCM_post_type_hcm_init")); // register a hcm post type.
		add_filter("the_content", array($this, "HCM_post_type_hcm_the_content")); // modif page for hcm
		add_action("rest_prepare_hcm", array($this, "HCM_rest_prepare_hcm"),10,3); 
		add_action("after_setup_theme", array($this, "HCM_image_size")); // register image size.
		add_filter("image_size_names_choose", array($this, "HCM_image_sizes_choose")); // image size choose.
		add_action("init", array($this, "HCM_register_taxonomy")); // register register_taxonomy.
		add_action("wp_head",array($this,"HCM_dinamic_js"),1); //load dinamic js
		if(is_admin()){
			add_action("add_meta_boxes",array($this,"HCM_metabox_course_name")); //add metabox Course Name
			add_action("save_post",array($this,"HCM_metabox_course_name_save")); //save metabox Course Name data
			add_action("admin_enqueue_scripts",array($this,"HCM_admin_enqueue_scripts")); //add js for admin
			add_action("admin_enqueue_scripts",array($this,"HCM_admin_enqueue_styles")); //add css for admin
			add_action("admin_menu", array($this, "HCM_admin_menu_hcm")); //create page admin
		}
	}


	/**
	 * Loads the plugin's translated strings
	 * @link http://codex.wordpress.org/Function_Reference/load_plugin_textdomain
	 * @access public
	 * @return void
	 **/
	public function HCM_textdomain()
	{
		load_plugin_textdomain("harvest-courses-demo", false, HCM_DIR . "/languages");
	}


	/**
	 * Add Metabox (course_name)
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/add_meta_box
	 * @param mixed $hooks
	 * @access public
	 * @return void
	 **/
	public function HCM_metabox_course_name($hook)
	{
		$allowed_hook = array("hcm"); //limit meta box to certain page
		if(in_array($hook, $allowed_hook))
		{
			add_meta_box("HCM_metabox_course_name", __("Course Name", "harvest-courses-demo"),array($this,"HCM_metabox_course_name_callback"),$hook,"normal","high");
		}
	}


	/**
	 * Create metabox markup (course_name)
	 * 
	 * @param mixed $post
	 * @access public
	 * @return void
	 **/
	public function HCM_metabox_course_name_callback($post)
	{
		// Add a nonce field so we can check for it later.
		wp_nonce_field("HCM_metabox_course_name_save","HCM_metabox_course_name_nonce");
		if(file_exists(HCM_PATH . "/includes/metabox.course_name.inc.php")){
			require_once(HCM_PATH . "/includes/metabox.course_name.inc.php");
			$course_name_metabox = new CourseName_Metabox();
			$course_name_metabox->Markup($post);
		}
	}


	/**
	 *
	 * Save the meta when the post is saved.
	 * HarvestCoursesDemo::HCM_metabox_course_name_save()
	 * @param int $post_id The ID of the post being saved.
	 *
	**/
	public function HCM_metabox_course_name_save($post_id)
	{

		/*
		 * We need to verify this came from the our screen and with proper authorization,
		 * because save_post can be triggered at other times.
		 */

		// Check if our nonce is set.
		if (!isset($_POST["HCM_metabox_course_name_nonce"]))
			return $post_id;
		$nonce = $_POST["HCM_metabox_course_name_nonce"];

		// Verify that the nonce is valid.
		if(!wp_verify_nonce($nonce, "HCM_metabox_course_name_save"))
			return $post_id;

		// If this is an autosave, our form has not been submitted,
		// so we don't want to do anything.
		if (defined("DOING_AUTOSAVE") && DOING_AUTOSAVE)
			return $post_id;

		// Check the user's permissions.
		if ("page" == $_POST["post_type"])
		{
			if (!current_user_can("edit_page", $post_id))
				return $post_id;
		} else
		{
			if (!current_user_can("edit_post", $post_id))
				return $post_id;
		}

		/* OK, its safe for us to save the data now. */

		// Sanitize the user input.
		//text
		$course_name = sanitize_text_field($_POST["HCM_postmeta_course_name"] );

		// Update the meta field.
		update_post_meta($post_id, "_HCM_postmeta_course_name", $course_name);

		// Sanitize the user input.
		//select
		$course_level = sanitize_text_field($_POST["HCM_postmeta_course_level"] );

		// Update the meta field.
		update_post_meta($post_id, "_HCM_postmeta_course_level", $course_level);

		// Sanitize the user input.
		//text
		$price = sanitize_text_field($_POST["HCM_postmeta_price"] );

		// Update the meta field.
		update_post_meta($post_id, "_HCM_postmeta_price", $price);

		// Sanitize the user input.
		//select
		$certificate = sanitize_text_field($_POST["HCM_postmeta_certificate"] );

		// Update the meta field.
		update_post_meta($post_id, "_HCM_postmeta_certificate", $certificate);

		// Sanitize the user input.
		//textarea
		$what_i_will_learn = sanitize_text_field($_POST["HCM_postmeta_what_i_will_learn"] );

		// Update the meta field.
		update_post_meta($post_id, "_HCM_postmeta_what_i_will_learn", $what_i_will_learn);

		// Sanitize the user input.
		//textarea
		$course_description = sanitize_text_field($_POST["HCM_postmeta_course_description"] );

		// Update the meta field.
		update_post_meta($post_id, "_HCM_postmeta_course_description", $course_description);

		// Sanitize the user input.
		//featured-image
		$course_image = sanitize_text_field($_POST["HCM_postmeta_course_image"] );

		// Update the meta field.
		update_post_meta($post_id, "_HCM_postmeta_course_image", $course_image);

	}




	/**
	 * Insert javascripts for back-end
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/wp_enqueue_script
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function HCM_admin_enqueue_scripts($hooks)
	{
		if (function_exists("get_current_screen")) {
			$screen = get_current_screen();
		}else{
			$screen = $hooks;
		}
	
		// limit page only hcm
		if(( in_array($hooks,array("hcm")))||( in_array($screen->post_type,array("hcm")))){
			wp_enqueue_script("HCM_admin_metabox", HCM_URL . "assets/js/HCM_admin_metabox.js", array("jquery","thickbox"),"1.0",true );
		}
	}


	/**
	 * Insert javascripts for front-end
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/wp_enqueue_script
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function HCM_enqueue_scripts($hooks)
	{
			wp_enqueue_script("HCM_main", HCM_URL . "assets/js/HCM_main.js", array("jquery"),"1.0",true );
	}


	/**
	 * Insert CSS for back-end
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/wp_register_style
	 * @link http://codex.wordpress.org/Function_Reference/wp_enqueue_style
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function HCM_admin_enqueue_styles($hooks)
	{
		if (function_exists("get_current_screen")) {
			$screen = get_current_screen();
		}else{
			$screen = $hooks;
		}
		// register css
		wp_register_style("HCM_metabox", HCM_URL . "assets/css/HCM_admin_metabox.css",array(),"1.0" );
	
		// limit page
		if(( in_array($hooks,array("hcm")))||( in_array($screen->post_type,array("hcm")))){
			wp_enqueue_style("HCM_metabox");
		}
	}


	/**
	 * Insert CSS for front-end
	 * 
	 * @link http://codex.wordpress.org/Function_Reference/wp_register_style
	 * @link http://codex.wordpress.org/Function_Reference/wp_enqueue_style
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function HCM_enqueue_styles($hooks)
	{
		// register css
		wp_register_style("HCM_main", HCM_URL . "assets/css/HCM_main.css",array(),"1.0" );
			wp_enqueue_style("HCM_main");
	}


	/**
	 * Add top level admin menu
	 * 
	 * @access public
	 * @return void
	 **/
	public function HCM_admin_menu_hcm()
	{
		add_menu_page(
			__("HCM","harvest-courses-demo"), //page title
			__("HCM","harvest-courses-demo"), //anchor link
			"read",
			"hcm",
			array($this,"HCM_admin_menu_hcm_markup"),
			"dashicons-welcome-learn-more",
			45
		);
	}


	/**
	 * Create markup for top level admin menu
	 * 
	 * @access public
	 * @return void
	 **/
	public function HCM_admin_menu_hcm_markup()
	{
		if(file_exists(HCM_PATH . "/includes/admin_menu.hcm.inc.php")){
			require_once(HCM_PATH . "/includes/admin_menu.hcm.inc.php");
			$hcm_admin_menu = new Hcm_adminMenu($this);
			$hcm_admin_menu->Markup();
		}
	}


	/**
	 * Register custom post types (hcm)
	 *
	 * @link http://codex.wordpress.org/Function_Reference/register_post_type
	 * @access public
	 * @return void
	 **/

	public function HCM_post_type_hcm_init()
	{

		$labels = array(
			'name' => _x('Courses', 'post type general name', 'harvest-courses-demo'),
			'singular_name' => _x('Course', 'post type singular name', 'harvest-courses-demo'),
			'menu_name' => _x('Course', 'admin menu', 'harvest-courses-demo'),
			'name_admin_bar' => _x('Courses', 'add new on admin bar', 'harvest-courses-demo'),
			'add_new' => _x('Add New Course', 'book', 'harvest-courses-demo'),
			'add_new_item' => __('New Courses', 'harvest-courses-demo'),
			'new_item' => __('New Courses', 'harvest-courses-demo'),
			'edit_item' => __('Edit Course', 'harvest-courses-demo'),
			'view_item' => __('View Course', 'harvest-courses-demo'),
			'all_items' => __('All Courses', 'harvest-courses-demo'),
			'search_items' => __('Search for course', 'harvest-courses-demo'),
			'parent_item_colon' => __('Parent Course', 'harvest-courses-demo'),
			'not_found' => __('No Courses', 'harvest-courses-demo'),
			'not_found_in_trash' => __('No Courses in Trash', 'harvest-courses-demo'));

			$supports = array('title','author','custom-fields','thumbnail');

			$args = array(
				'labels' => $labels,
				'description' => __('Harvest (Dubai) Courses management plugin - demo version for Majdi Awad CV.', 'harvest-courses-demo'),
				'public' => true,
				'menu_icon' => 'dashicons-welcome-learn-more',
				'publicly_queryable' => true,
				'show_ui' => true,
				'show_in_menu' => true,
				'query_var' => true,
				'rewrite' => array('slug' => 'hcm'),
				'capability_type' => 'post',
				'has_archive' => true,
				'hierarchical' => true,
				'menu_position' => null,
				'show_in_rest' => true,
				'rest_base' => 'hcm',
				'taxonomies' => array(), // array('category', 'post_tag','page-category'),
				'supports' => $supports);

			register_post_type('hcm', $args);

		// create single template
		add_filter("single_template", array($this, "HCM_post_type_hcm_single_template"));

	}


	/**
	 * Load Single Template (hcm)
	 *
	 * @access public
	 * @param mixed $single_template
	 * @return void
	 **/

	public function HCM_post_type_hcm_single_template($single_template)
	{

		global $post;
		if(file_exists(HCM_PATH . "/templates/single-hcm.php" ))
		{
			if ($post->post_type == "hcm")
			{
				$single_template = HCM_PATH . "/templates/single-hcm.php";
			}
		}
		return $single_template;
	}


	/**
	 * Retrieved data custom post-types (hcm)
	 *
	 * @access public
	 * @param mixed $content
	 * @return void
	 * @link https://codex.wordpress.org/Plugin_API/Filter_Reference/the_content
	 **/

	public function HCM_post_type_hcm_the_content($content)
	{

		$new_content = $content ;
		if(is_singular("hcm")){
			if(file_exists(HCM_PATH . "/includes/post_type.hcm.inc.php")){
				require_once(HCM_PATH . "/includes/post_type.hcm.inc.php");
				$hcm_content = new Hcm_TheContent();
				$new_content = $hcm_content->Markup($content);
				wp_reset_postdata();
			}
		}

		return $new_content ;

	}


	/**
	 * rest prepare
	 *
	 * @access public
	 * @param mixed $data
	 * @param mixed $term
	 * @param mixed $context
	 * @return void
	 * @link https://developer.wordpress.org/reference/hooks/rest_prepare_this-post_type/
	 **/

	public function HCM_rest_prepare_hcm($data,$term,$context)
	{
		$oldData = $data->data;
		$newData = $oldData;
		$newData["post_meta"] = get_post_meta($oldData["id"],"",true);
		$data->data = $newData;
		return $data;
	}


	/**
	 * Register a new image size.
	 * @link http://codex.wordpress.org/Function_Reference/add_image_size
	 * @access public
	 * @return void
	 **/
	public function HCM_image_size()
	{
	}


	/**
	 * Choose a image size.
	 * @access public
	 * @param mixed $sizes
	 * @return void
	 **/
	public function HCM_image_sizes_choose($sizes)
	{
		$custom_sizes = array(
		);
		return array_merge($sizes,$custom_sizes);
	}


	/**
	 * Register Taxonomies
	 * @https://codex.wordpress.org/Taxonomies
	 * @access public
	 * @return void
	 **/
	public function HCM_register_taxonomy()
	{
	}


	/**
	 * Insert Dinamic JS
	 * @param object $hooks
	 * @access public
	 * @return void
	 **/
	public function HCM_dinamic_js($hooks)
	{
		_e("<script type=\"text/javascript\">");
		_e("</script>");
	}
}


new HarvestCoursesDemo();
