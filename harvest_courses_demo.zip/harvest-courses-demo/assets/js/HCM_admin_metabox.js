/**
 * @Author :Majdi Awad
 * @Author URL : http://googlit.tech/
 * @License : http://googlit.tech/
 * @License URL: http://googlit.tech/
 *
 * @Package : Harvest Courses - Demo
 * @Version : 1.0
**/


(function($)
{
	
	/**
	 * COURSE NAME
	 * name :course_name
	 * postmeta : course_name
	 * label : Course Name
	**/
	
	/**
	 * COURSE NAME
	 * name :course_name
	 * postmeta : course_level
	 * label : Course Level
	**/
	
	/**
	 * COURSE NAME
	 * name :course_name
	 * postmeta : price
	 * label : Price
	**/
	
	/**
	 * COURSE NAME
	 * name :course_name
	 * postmeta : certificate
	 * label : Certificate
	**/
	
	/**
	 * COURSE NAME
	 * name :course_name
	 * postmeta : what_i_will_learn
	 * label : What I will learn
	**/
	
	/**
	 * COURSE NAME
	 * name :course_name
	 * postmeta : course_description
	 * label : Course Description
	**/
	
	/**
	 * COURSE NAME
	 * name :course_name
	 * postmeta : course_image
	 * label : Course Image
	**/
		
		
		
		$(function(){
		  // Set all variables to be used in scope
		  var frame_HCM_postmeta_course_image,
		      metaBox_HCM_postmeta_course_image = $('.postbox'), // Your meta box id here
		      addImgLink_HCM_postmeta_course_image= metaBox_HCM_postmeta_course_image.find('.HCM_postmeta_course_image-upload-img'),
		      delImgLink_HCM_postmeta_course_image = metaBox_HCM_postmeta_course_image.find( '.HCM_postmeta_course_image-delete-img'),
		      imgContainer_HCM_postmeta_course_image = metaBox_HCM_postmeta_course_image.find( '.HCM_postmeta_course_image-img-container'),
		      imgIdInput_HCM_postmeta_course_image = metaBox_HCM_postmeta_course_image.find( '.HCM_postmeta_course_image-img-id' );
		  
		  // ADD IMAGE LINK
		  addImgLink_HCM_postmeta_course_image.on( 'click', function( event ){
		    
		    event.preventDefault();
		    
		    // If the media frame already exists, reopen it.
		    if ( frame_HCM_postmeta_course_image ) {
		      frame_HCM_postmeta_course_image.open();
		      return;
		    }
		    
		    // Create a new media frame
		    frame_HCM_postmeta_course_image = wp.media({
		      title: 'Select or Upload Media Of Your Chosen Persuasion',
		      button: {
		        text: 'Use this media'
		      },
		      multiple: false  // Set to true to allow multiple files to be selected
		    });
		    
		    // When an image is selected in the media frame...
		    frame_HCM_postmeta_course_image.on( 'select', function() {
		      
		      // Get media attachment details from the frame state
		      var attachment = frame_HCM_postmeta_course_image.state().get('selection').first().toJSON();
		      // Send the attachment URL to our custom image input field.
		      imgContainer_HCM_postmeta_course_image.append( '<img src="'+attachment.url+'" alt="" style="max-width:180px;"/>' );
		      // Send the attachment id to our hidden input
		      imgIdInput_HCM_postmeta_course_image.val( attachment.id );
		      // Hide the add image link
		      addImgLink_HCM_postmeta_course_image.addClass( 'hidden' );
		      // Unhide the remove image link
		      delImgLink_HCM_postmeta_course_image.removeClass( 'hidden' );
		    });
		    // Finally, open the modal on click
		    frame_HCM_postmeta_course_image.open();
		  });
		  
		  
		  // DELETE IMAGE LINK
		  delImgLink_HCM_postmeta_course_image.on( 'click', function( event ){
		    event.preventDefault();
		    // Clear out the preview image
		    imgContainer_HCM_postmeta_course_image.html( '' );
		    // Un-hide the add image link
		    addImgLink_HCM_postmeta_course_image.removeClass( 'hidden' );
		    // Hide the delete image link
		    delImgLink_HCM_postmeta_course_image.addClass( 'hidden' );
		    // Delete the image id from the hidden input
		    imgIdInput_HCM_postmeta_course_image.val( '' );
		  });
		});
})(jQuery);
