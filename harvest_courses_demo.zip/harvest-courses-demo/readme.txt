=== Harvest Courses - Demo ===

Contributors: Majdi Awad 
Donate link: http://ihsana.com
Tags:  lms,courses
Requires at least: 3.4
Tested up to: 3.6
Stable tag: 3.6
License: http://googlit.tech/
License URI: http://googlit.tech/

== Description ==
Courses management plugin for WordPress. Built by majdi awad for harvest training (Dubai) and this is just a demo version to be added to my resume.

== Installation ==
1. Unzip and Upload `harvest-courses-demo.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Make configuration setting in plugin setting page.
4. hit "save setting" button.

== Frequently asked questions ==
Q: I can not access page hcm, it say error `Oops! That page can't be found.`
A: Go Settings Menu - permalink and click `Save Changes` again."

== Screenshots ==

== Changelog ==

== Credits ==

== Upgrade Notice == 