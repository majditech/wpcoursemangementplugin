<?php

/**
 * Top Level Admin Menu (hcm)
 *
**/

# Exit if accessed directly
if(!defined("HCM_EXEC")){
	die();
}


 /**
  * Dispaly back-end admin menu hcm
  * 
  * @package Harvest Courses - Demo
  * @author Majdi Awad
  * @version 1.0
  * @access public
  */

class Hcm_adminMenu{

	/**
	 * Option Plugin
	 * @access private
	 **/
	private $options;

	/**
	 * Instance of a class
	 * 
	 * @access public
	 * @return void
	 **/
	function __construct(){
		$this->options = get_option("harvest_courses_demo_plugins"); // get current option
	}

	/**
	 * Create Admin Menu Markup
	 * 
	 * @access public
	 * @return void
	 **/

	public function Markup(){

		// TODO: EDIT HTML ADMIN HCM
		/**
		* You can make admin page here
		**/

		echo "<div class=\"wrap\">";
		echo "<h2>" . __("HCM","harvest-courses-demo") . "</h2>";
		// Display file path
		if(HCM_DEBUG==true){
			$file_info = null; 
			$file_info .= "<div>" ; 
			$file_info .= "<pre style=\"color:rgba(255,0,0,1);padding:3px;margin:0px;background:rgba(255,0,0,0.1);border:1px solid rgba(255,0,0,0.5);font-size:11px;font-family:monospace;white-space:pre-wrap;\">%s:%s</pre>" ; 
			$file_info .= "</div>" ; 
			printf($file_info,__FILE__,__LINE__);
		}
		echo "<h4>This Admin Menu Code</h4>";
		echo "</div>";
	}
}
