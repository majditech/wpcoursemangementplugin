<?php

/**
 * Metabox (Course Name)
 *
**/

# Exit if accessed directly
if(!defined("HCM_EXEC")){
	die();
}


 /**
  * Dispaly back-end metabox course_name
  * 
  * @package Harvest Courses - Demo
  * @author Majdi Awad
  * @version 1.0
  * @access public
  * 
  * Generate by Plugin Maker ~ http://codecanyon.net/item/wordpress-plugin-maker-freelancer-version/13581496
  */

class CourseName_Metabox{


	/**
	 * Option Plugin
	 * @access private
	 **/
	private $options;

	/**
	 * Instance of a class
	 * 
	 * @access public
	 * @return void
	 **/

	function __construct(){
		$this->options = get_option("harvest_courses_demo_plugins"); // get current option

	}

	/**
	 * Create Metabox Markup
	 * 
	 * @param mixed $post
	 * @access public
	 * @return void
	 **/

	public function Markup($post){

		// TODO: EDIT HTML METABOX COURSE NAME
		if(HCM_DEBUG==true){
			$file_info = null; 
			$file_info .= "<p>You can edit the file below to fix the metabox</p>" ; 
			$file_info .= "<div>" ; 
			$file_info .= "<pre style=\"color:rgba(255,0,0,1);padding:3px;margin:0px;background:rgba(255,0,0,0.1);border:1px solid rgba(255,0,0,0.5);font-size:11px;font-family:monospace;white-space:pre-wrap;\">%s:%s</pre>" ; 
			$file_info .= "</div>" ; 
			printf($file_info,__FILE__,__LINE__);
		}
		/**
		* You can make HTML tag for Metabox Course Name here
		**/

		echo "<h4>Course Details</h4>";
		printf("<table class=\"form-table\">");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_HCM_postmeta_course_name= get_post_meta($post->ID, "_HCM_postmeta_course_name", true);

		/** Display the form course_name, using the current value. **/
		printf("<tr><th scope=\"row\"><label for=\"HCM_postmeta_course_name\">%s</label></th><td><input class=\"HCM-form-control\" type=\"text\" id=\"HCM_postmeta_course_name\" name=\"HCM_postmeta_course_name\" value=\"%s\" placeholder=\"Course Name Here\" /></td></tr>",__("Course Name", "harvest-courses-demo"), esc_attr($current_HCM_postmeta_course_name));


		// Use get_post_meta to retrieve an existing value from the database.
		$current_HCM_postmeta_course_level= get_post_meta($post->ID, "_HCM_postmeta_course_level", true);

		/** Display the form course_level, using the current value. **/
		$input_options = array();
		$input_options[] = array("value"=>"beginners","label"=>__("Beginners","harvest-courses-demo")) ;
		$input_options[] = array("value"=>"experts","label"=>__("Experts","harvest-courses-demo")) ;
		$input_options[] = array("value"=>"advance","label"=>__("Advance","harvest-courses-demo")) ;
		printf("<tr>");
		printf("<th scope=\"row\"><label class=\"HCM-control-label\" for=\"HCM_postmeta_course_level\">". __("Course Level", "harvest-courses-demo"). "</label></th>");
		printf("<td>");
		printf("<select class=\"HCM HCM-form-control\" id=\"HCM_postmeta_course_level\" name=\"HCM_postmeta_course_level\" >") ;
		foreach ($input_options as $input_option)
		{
			$selected="";
			if($input_option["value"]== $current_HCM_postmeta_course_level){ $selected="selected=\"selected\"";}
			printf("<option value='".$input_option["value"]."' ".$selected.">".$input_option["label"]."</option>") ;
		}
		printf("</select>") ;
		printf("</td>") ;
		printf("</tr>");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_HCM_postmeta_price= get_post_meta($post->ID, "_HCM_postmeta_price", true);

		/** Display the form price, using the current value. **/
		printf("<tr><th scope=\"row\"><label for=\"HCM_postmeta_price\">%s</label></th><td><input class=\"HCM-form-control\" type=\"text\" id=\"HCM_postmeta_price\" name=\"HCM_postmeta_price\" value=\"%s\" placeholder=\"Course Total Price\" /></td></tr>",__("Price", "harvest-courses-demo"), esc_attr($current_HCM_postmeta_price));


		// Use get_post_meta to retrieve an existing value from the database.
		$current_HCM_postmeta_certificate= get_post_meta($post->ID, "_HCM_postmeta_certificate", true);

		/** Display the form certificate, using the current value. **/
		$input_options = array();
		$input_options[] = array("value"=>"course","label"=>__("Course","harvest-courses-demo")) ;
		$input_options[] = array("value"=>"diploma","label"=>__("Dibloma","harvest-courses-demo")) ;
		printf("<tr>");
		printf("<th scope=\"row\"><label class=\"HCM-control-label\" for=\"HCM_postmeta_certificate\">". __("Certificate", "harvest-courses-demo"). "</label></th>");
		printf("<td>");
		printf("<select class=\"HCM HCM-form-control\" id=\"HCM_postmeta_certificate\" name=\"HCM_postmeta_certificate\" >") ;
		foreach ($input_options as $input_option)
		{
			$selected="";
			if($input_option["value"]== $current_HCM_postmeta_certificate){ $selected="selected=\"selected\"";}
			printf("<option value='".$input_option["value"]."' ".$selected.">".$input_option["label"]."</option>") ;
		}
		printf("</select>") ;
		printf("</td>") ;
		printf("</tr>");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_HCM_postmeta_what_i_will_learn= get_post_meta($post->ID, "_HCM_postmeta_what_i_will_learn", true);

		/** Display the form what_i_will_learn, using the current value. **/
		printf("<tr>");
		printf("<th scope=\"row\"><label for=\"HCM_postmeta_what_i_will_learn\">". __("What I will learn", "harvest-courses-demo"). "</label></th>");
		printf("<td class=\"HCM HCM-col-sm-10\"><textarea class=\"HCM-form-control\" type=\"text\" id=\"HCM_postmeta_what_i_will_learn\" name=\"HCM_postmeta_what_i_will_learn\" placeholder=\" \">" . esc_attr($current_HCM_postmeta_what_i_will_learn) . "</textarea></td>");
		printf("</tr>");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_HCM_postmeta_course_description= get_post_meta($post->ID, "_HCM_postmeta_course_description", true);

		/** Display the form course_description, using the current value. **/
		printf("<tr>");
		printf("<th scope=\"row\"><label for=\"HCM_postmeta_course_description\">". __("Course Description", "harvest-courses-demo"). "</label></th>");
		printf("<td class=\"HCM HCM-col-sm-10\"><textarea class=\"HCM-form-control\" type=\"text\" id=\"HCM_postmeta_course_description\" name=\"HCM_postmeta_course_description\" placeholder=\" \">" . esc_attr($current_HCM_postmeta_course_description) . "</textarea></td>");
		printf("</tr>");


		// Use get_post_meta to retrieve an existing value from the database.
		$current_HCM_postmeta_course_image= get_post_meta($post->ID, "_HCM_postmeta_course_image", true);

		/** Display the form course_image, using the current value. **/
		wp_enqueue_media();
		printf("<tr>");
		printf("<th scope=\"row\"><label class=\"HCM HCM-col-sm-2 HCM-control-label\" for=\"HCM_postmeta_course_image\">". __("Course Image", "harvest-courses-demo"). "</label></th>");
		printf("<td>");
		global $post;
		// Get WordPress media upload URL
		$HCM_postmeta_course_image_upload_link = esc_url( get_upload_iframe_src("image", $post->ID ) );
		// Get the image src
		$HCM_postmeta_course_image_img_src = wp_get_attachment_image_src($current_HCM_postmeta_course_image, "full" );
		// For convenience, see if the array is valid
		$HCM_postmeta_course_image_have_img = is_array( $HCM_postmeta_course_image_img_src );
		print( "<div class=\"HCM_postmeta_course_image-img-container\">");
		if ( $HCM_postmeta_course_image_have_img ){
		print("<img src=\"". $HCM_postmeta_course_image_img_src[0] ."\" alt=\"\" style=\"max-width:100%;\" />");
		}
		print("</div>");
		print("<p class=\"hide-if-no-js\">");
		print("<a class=\"HCM_postmeta_course_image-upload-img ");
		if($HCM_postmeta_course_image_have_img){echo "hidden";}
		print( "\"  href=\"".  $upload_link ."\">");
		_e("Set custom image");
		print( "</a>");
		print( "<a class=\"HCM_postmeta_course_image-delete-img ");
		if ( ! $HCM_postmeta_course_image_have_img  ) { echo "hidden"; }
		print( "\" href=\"#\">");
		_e("Remove this image");
		print( "</a>");
		print( "</p>");
		print( "<input class=\"HCM_postmeta_course_image-img-id\" name=\"HCM_postmeta_course_image\" type=\"hidden\" value=\"". esc_attr($current_HCM_postmeta_course_image)."\" />");
		printf("</td>");
		printf("</tr>");
		echo "</table>";
	}
}
