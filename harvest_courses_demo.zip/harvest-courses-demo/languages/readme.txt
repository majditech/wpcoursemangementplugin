Create a file POT, PO and MO using POEdit or Loco Translate Plugin, 
then rename accordance with textdomain used by the plugin, as follows:

* harvest-courses-demo-de_DE.po
* harvest-courses-demo-id_ID.po
* harvest-courses-demo-es_ES.po
* harvest-courses-demo-en_US.po

* harvest-courses-demo-de_DE.mo
* harvest-courses-demo-id_ID.mo
* harvest-courses-demo-es_ES.mo
* harvest-courses-demo-en_US.mo


Download:
* http://wordpress.org/extend/plugins/loco-translate
* http://poedit.net/download
